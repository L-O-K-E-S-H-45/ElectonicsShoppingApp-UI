import React from 'react'

const BecomeASeller = () => {
  return (
    <div>BecomeASeller</div>
  )
}

export default BecomeASeller