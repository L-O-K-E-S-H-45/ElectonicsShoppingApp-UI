import React from 'react'

const PageNotFound = () => {
  return (
      <div className='text-black font-bold text-5xl flex justify-center mt-10'>
        <h2>404 - Page Not Found</h2>    
      </div>
      
  )
}

export default PageNotFound