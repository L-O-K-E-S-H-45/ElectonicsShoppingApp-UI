import React from 'react'

const VerifyOTP = () => {
  return (
    <div>VerifyOTP</div>
  )
}

export default VerifyOTP