import React from 'react'

const SellerOrders = () => {
  return (
    <div>SellerOrders</div>
  )
}

export default SellerOrders