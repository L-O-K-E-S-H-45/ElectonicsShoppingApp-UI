import React from 'react'

const SellerDashBoard = () => {
  return (
    <div>SellerDashBoard</div>
  )
}

export default SellerDashBoard