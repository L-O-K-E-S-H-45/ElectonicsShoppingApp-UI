import React from 'react'

const Account = () => {
  return (
    <div>Account</div>
  )
}

export default Account